package org.oss.pdfreporter.compilers.expressionelements;

public interface ExpressionConstants {

	String EXP_TRUE = "1.0";
	String QUOTED_NULL = "'#null#'";
	String UNQUOTED_NULL = "#null#";
}
