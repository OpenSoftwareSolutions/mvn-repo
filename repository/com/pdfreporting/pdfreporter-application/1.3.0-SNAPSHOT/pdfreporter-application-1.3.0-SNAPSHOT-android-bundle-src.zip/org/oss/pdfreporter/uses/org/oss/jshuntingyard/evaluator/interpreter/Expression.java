package org.oss.pdfreporter.uses.org.oss.jshuntingyard.evaluator.interpreter;

import java.util.ArrayList;

public class Expression extends ArrayList<ExpressionElement> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}
