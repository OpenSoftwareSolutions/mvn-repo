package org.oss.pdfreporter.uses.org.oss.jshuntingyard.evaluator.operator.cast;

public interface ResultCastCapable {
	String getNamePrefix();
}
