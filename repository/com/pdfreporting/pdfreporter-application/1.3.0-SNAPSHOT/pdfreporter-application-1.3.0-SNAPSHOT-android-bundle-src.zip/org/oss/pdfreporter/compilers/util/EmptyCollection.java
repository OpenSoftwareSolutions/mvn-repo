/*******************************************************************************
 * Copyright (c) 2015 Open Software Solutions GmbH.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Lesser Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/lgpl-3.0.html
 * 
 * Contributors:
 *     Open Software Solutions GmbH
 ******************************************************************************/
package org.oss.pdfreporter.compilers.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

import org.oss.pdfreporter.compilers.ExpressionEvaluationException;
import org.oss.pdfreporter.compilers.ExpressionParseException;
import org.oss.pdfreporter.compilers.IExpressionElement;
import org.oss.pdfreporter.compilers.expressionelements.AbstractExpressionElement;


public class EmptyCollection extends AbstractExpressionElement implements IExpressionElement{
	private static String ARRAYLIST_MATCH = "new java.util.ArrayList()";
	private static String HASHSET_MATCH = "new java.util.HashSet()";
	
	private final Collection<?> collection;

	public static boolean isCollection(String text) {
		return text.equals(ARRAYLIST_MATCH) ||
				 text.equals(HASHSET_MATCH);
	}
	
	@SuppressWarnings("rawtypes")
	public static EmptyCollection parseCollection(String s) throws ExpressionParseException {
		if (s.equals(ARRAYLIST_MATCH)) {
			return new EmptyCollection(new ArrayList());
		} else if (s.equals(HASHSET_MATCH)) {
			return new EmptyCollection(new HashSet());
		} 
		throw new ExpressionParseException("Unsupported Collection " + s);
	}
	
	
	public EmptyCollection(Collection<?> collection) {
		this.collection = collection;
	}

	@Override
	public Object getValue() throws ExpressionEvaluationException {
		return collection;
	}
}
