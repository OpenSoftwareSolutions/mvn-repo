/*******************************************************************************
 * Copyright (c) 2013 Open Software Solutions GmbH.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Lesser Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/lgpl-3.0.html
 *
 * Contributors:
 *     Open Software Solutions GmbH - initial API and implementation
 ******************************************************************************/
package org.oss.pdfreporter.compilers.jshuntingyard.functions;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.oss.pdfreporter.uses.org.oss.jshuntingyard.evaluator.AbstractFunctionElement;
import org.oss.pdfreporter.uses.org.oss.jshuntingyard.evaluator.FunctionArgumentFactory;
import org.oss.pdfreporter.uses.org.oss.jshuntingyard.evaluator.FunctionElementArgument;

/**
 * java.text.MessageFormat style Messages
 * @author donatmuller, 2015, last change 15:08:34
 */
public class MessageWithArgs extends AbstractFunctionElement  {


	public MessageWithArgs() {
		super("message", -1, Precedence.USERFUNCTION);
	}


	@Override
	public boolean isUserFunction() {
		return true;
	}


	@Override
	public FunctionElementArgument<?> execute(
			FunctionElementArgument<?>... args) throws IllegalArgumentException {
		List<Object> messageArgs = new ArrayList<Object>();
		if (isString(args[0])) {
			String text = (String) args[0].getValue();
			for (int i=1; i<args.length; i++) {
				// TODO toString only for compability with JEval check JasperReports as reference
				messageArgs.add(args[i].getValue().toString());
			}
			String result = MessageFormat.format(text, messageArgs.toArray());
			return FunctionArgumentFactory.createString(result);
		} else {
			throw new IllegalArgumentException("First parameter must a String with a message pattern and not " + args[0].getType());
		}
	}
}